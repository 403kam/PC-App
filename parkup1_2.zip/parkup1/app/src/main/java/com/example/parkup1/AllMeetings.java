package com.example.parkup1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
//import android.support.v7.app.AppCompatActivity;

public class AllMeetings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.allmeetings);

        /*
        final TextView ymca2 = findViewById(R.id.ymca2);
        ymca2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent11 = new Intent(AllMeetings.this,
                        Ymca.class);
                startActivity(intent11);
            }

        });

        final TextView lonergan2 = findViewById(R.id.lonergan2);
        lonergan2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent13 = new Intent(AllMeetings.this,
                        Lonergan.class);
                startActivity(intent13);
            }

        });
         */

    }

}