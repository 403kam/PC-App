package com.example.parkup1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
//import android.support.v7.app.AppCompatActivity;

public class MeetingsICreated extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meetingsicreated);

        /*

        final TextView lonergan3 = findViewById(R.id.lonergan3);
        lonergan3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent15 = new Intent(MeetingsICreated.this,
                        Lonergan.class);
                startActivity(intent15);
            }

        });
         */

    }

}